-- Stored Procedures
CREATE   PROCEDURE startAuction
AS
DECLARE @date_debut date
DECLARE date_begin_cursor CURSOR FOR
SELECT date_debut_encheres
FROM ARTICLES_VENDUS
WHERE etat_vente = 'PC';

OPEN date_begin_cursor
FETCH NEXT FROM date_begin_cursor
    INTO @date_debut

WHILE @@FETCH_STATUS = 0
BEGIN
    IF @date_debut <= GETDATE()
        BEGIN
            UPDATE ARTICLES_VENDUS SET etat_vente = 'EC' WHERE date_debut_encheres = @date_debut
        END
    FETCH NEXT FROM date_begin_cursor
        INTO @date_debut
END
CLOSE date_begin_cursor
DEALLOCATE date_begin_cursor
go

