CREATE   PROCEDURE endAuction
AS
DECLARE @date_fin date
DECLARE date_end_cursor CURSOR FOR
    SELECT date_fin_encheres
    FROM ARTICLES_VENDUS
    WHERE etat_vente = 'EC';

    OPEN date_end_cursor
    FETCH NEXT FROM date_end_cursor
        INTO @date_fin

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @date_fin <= GETDATE()
            BEGIN
                UPDATE ARTICLES_VENDUS SET etat_vente = 'VE' WHERE date_fin_encheres = @date_fin
            END
        FETCH NEXT FROM date_end_cursor
            INTO @date_fin
    END
    CLOSE date_end_cursor
    DEALLOCATE date_end_cursor
go

